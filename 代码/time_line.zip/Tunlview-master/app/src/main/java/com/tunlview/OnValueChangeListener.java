package com.tunlview;

/**
 * Created by Administrator on 2017/10/19.
 */

public interface OnValueChangeListener {
    public void onValueChange(float value);

}
